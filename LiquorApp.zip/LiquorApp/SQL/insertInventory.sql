insert into inventory (fullBottles, productID, partial_weight) values('3','1','2.4');
insert into inventory (fullBottles, productID, partial_weight) values('2','2','1.8');
insert into inventory (fullBottles, productID, partial_weight) values('1','3','1.3');
insert into inventory (fullBottles, productID, partial_weight) values('3','4','3.2');
insert into inventory (fullBottles, productID, partial_weight) values('3','5','2.4');

