insert into product (brand, cost,full_weight) values('Beefeater','25','3.6');
insert into product (brand, cost,full_weight) values('Avion','30','3.6');
insert into product (brand, cost,full_weight) values('Bacardi','20','3.2');
insert into product (brand, cost,full_weight) values('Goose','30','3.8');
insert into product (brand, cost,full_weight) values('Jack','25','3.4');
